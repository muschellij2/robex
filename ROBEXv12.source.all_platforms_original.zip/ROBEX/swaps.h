void fix_double(double *a);
void fix_int(int *a);