#define MAX_R 30000
int load_nrnodes();
int load_ntree();
double * load_xbestsplit();
double *load_classwt();
double *load_cutoff();
int *load_treemap();
int *load_nodestatus();
int *load_nodeclass();
int *load_bestvar();
int *load_ndbigtree();
int load_nclass();
int load_predict_all();
